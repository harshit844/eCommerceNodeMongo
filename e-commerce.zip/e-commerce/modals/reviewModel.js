const mongoose = require('mongoose');

const reviewSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: [true, 'Review must belongs to a user']
    },
    product_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Product',
        required: [true, 'Review must belongs to a product']
    },
    rating: {
        type: Number,
        min: 1,
        max: 5,
        required: [true, 'Please rate the product']
    },
    comment: String,
    status: {
        type: Number,
        default: 1,
        enum: [0, 1]
    },
    isDeleted: {
        type : Date,
        default: null
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
});

reviewSchema.pre(/^find/, function(next){
    this.populate({
        path: 'user_id',
        select: 'name photo',
    });
    next();
});

module.exports = mongoose.model("Review", reviewSchema);