const path = require('path');
const validator = require('validator');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mongoose = require('mongoose');
const crypto = require('crypto');

const userSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, "Please enter your name"],
        maxlength: [30, "Name can not be more than 30 charactors"],
        minlength: [3, "Name can not be less than 3 charactors"]
    },
    email: {
        type: String,
        required: [true, "Please enter your email"],
        unique: true,
        validate: [validator.isEmail, "Please enter a valid email"]
    },
    mobile_no: {
        type: String,
        required: [true, "Please enter your mobile number"],
        unique: true
    },
    photo: {
        type: String,
        default: null
    },
    password: {
        type: String,
        minlength: [5, "Password can not be less than 5 charactors"],
        trim: true,
        select: false
    },
    role: {
        type: String,
        default: 'user',
        enum: ['admin', 'user']
    },
    emailVerified: {
        type: Date,
        default: null
    },
    ipAddress: {
        type: String,
        default: null
    },
    isDeleted: {
        type: Date,
        default: null
    },
    last_login: Date,
    resetPasswordToken: String,
    resetPasswordExpiry: Date,
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
},{
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

userSchema.virtual('photo_path').get(function() {
    if(this.photo){
        if(process.env.NODE_ENV === 'dev'){
            return `http://localhost:5000/images/users/${this.photo}`;
        }else{
            return `https://${process.env.DOMAIN}/images/users/${this.photo}`;
        }
    }
});

userSchema.pre('save', async function (next) {
    if (!this.isModified("password")) {
        next();
    }
    this.password = await bcrypt.hash(this.password, 10);
});

// JWT Token
userSchema.methods.getJWTToken = function () {
    return jwt.sign({ _id: this._id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRE
    });
}

userSchema.methods.comparePassword = async function (enterPassword) {
    return await bcrypt.compare(enterPassword, this.password);
}

userSchema.methods.getResetPasswordToken = function () {
    // Generating token
    const resetToken = crypto.randomBytes(20).toString("hex");

    // Hashing and storing the resetPasswordToken to userSchema
    this.resetPasswordToken = crypto.createHash("sha256").update(resetToken).digest("hex");
    this.resetPasswordExpiry = Date.now() + 15 * 60 * 1000;
    return resetToken;
};

module.exports = mongoose.model("User", userSchema);