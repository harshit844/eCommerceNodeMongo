const mongoose = require('mongoose');

// status 0=inactive, 1=active, 2=default selected address
const addressSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'User'
    },
    address_line: String,
    city: String,
    postal_code: Number,
    mobile_no: String,
    status: {
        type: Number,
        default: 1,
        enum: [0, 1, 2]
    },
    isDeleted: {
        type : Date,
        default: null
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
});

addressSchema.pre(/^find/, function(next){
    this.populate({
        path: 'user_id',
        select: '-__v -created_time -updated_time',
    });
    next();
});

module.exports = mongoose.model("Address", addressSchema);