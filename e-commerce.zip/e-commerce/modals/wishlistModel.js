const mongoose = require('mongoose');

const wishlistSchema = new mongoose.Schema({
    user_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: [true, 'Wishlist must belongs to a user']
    },
    product_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Product',
        required: [true, 'Wishlist must belongs to a product']
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
});

wishlistSchema.pre(/^find/, function(next){
    this.populate({
        path: 'user_id',
        select: 'name photo',
    }).populate({
        path: 'product_id'
    });
    next();
});

module.exports = mongoose.model("Wishlist", wishlistSchema);