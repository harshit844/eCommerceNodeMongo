const mongoose = require('mongoose');
const validator = require('validator');

const otpSchema = new mongoose.Schema({
    mobile_no: {
        type: String,
        required: [true, "Please enter mobile number"]
    },
    otp_sent: {
        type: Number,
        required: [true, "Please enter otp"]
    },
    expiration: { 
        type: Date,
        default: Date.now
    },
    retry_count: { 
        type: Number,
        default: 0
    },
    created_time: {
        type: Date,
        default: Date.now
    },
    updated_time: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model("OTP", otpSchema);