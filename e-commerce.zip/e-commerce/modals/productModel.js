const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
    category_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Category'
    },
    name: {
        type: String,
        required: [true, "Please enter name"]
    },
    description: String,
    photo: {
        type: String,
        default: null
    },
    price: Number,
    stock: Number,
    status: {
        type: Number,
        default: 1,
        enum: [0, 1]
    },
    isDeleted: {
        type: Date,
        default: null
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
},{
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

productSchema.virtual('photo_path').get(function() {
    if(this.photo){
        if(process.env.NODE_ENV === 'dev'){
            return `http://localhost:5000/images/products/${this.photo}`;
        }else{
            return `https://${process.env.DOMAIN}/images/products/${this.photo}`;
        }
    }
});

productSchema.virtual('reviews', {
    ref: 'Review',
    foreignField: 'product_id',
    localField: '_id'
});

productSchema.pre(/^find/, function (next) {
    this.populate({
        path: 'category_id',
        select: '-__v -created_time -updated_time -photo -description -isDeleted',
    });
    next();
});

module.exports = mongoose.model("Product", productSchema);