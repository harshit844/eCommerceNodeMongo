const mongoose = require('mongoose');

const bannerSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter banner title']
    },
    category: {
        type: String,
        required: [true, 'Please enter banner type']
    },
    photo: String,
    order: {
        type: Number,
        required: [true, 'Please enter the banner order'],
        unique: true
    },
    status: {
        type: Number,
        default: 1,
        enum: [0, 1]
    },
    isDeleted: {
        type : Date,
        default: null
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
},{
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

bannerSchema.virtual('photo_path').get(function() {
    if(this.photo){
        if(process.env.NODE_ENV === 'dev'){
            return `http://localhost:5000/images/banners/${this.photo}`;
        }else{
            return `https://${process.env.DOMAIN}/images/banners/${this.photo}`;
        }
    }
});

module.exports = mongoose.model("Banner", bannerSchema);