const mongoose = require('mongoose');

const categorySchema = new mongoose.Schema({
    name: String,
    description: String,
    photo: {
        type: String,
        default: null
    },
    isDeleted: {
        type: Date,
        default: null
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
},{
    toJSON: { virtuals: true },
    toObject: { virtuals: true }
});

categorySchema.virtual('photo_path').get(function() {
    if(this.photo){
        if(process.env.NODE_ENV === 'dev'){
            return `http://localhost:5000/images/categories/${this.photo}`;
        }else{
            return `https://${process.env.DOMAIN}/images/categories/${this.photo}`;
        }
    }
});

module.exports = mongoose.model("Category", categorySchema);