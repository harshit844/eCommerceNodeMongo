const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
    product_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'Product',
        required: [true, 'Product is required for order']
    },
    user_id: {
        type: mongoose.Schema.ObjectId,
        ref: 'User',
        required: [true, 'User is required for order']
    },
    quantity: {
        type: Number,
        required: [true, 'Please enter quantity']
    },
    discount_amount: {
        type: Number,
        default: null
    },
    tax_amount: {
        type: Number,
        required: [true, 'Please enter tax amount']
    },
    unit_amount: {
        type: Number,
        required: [true, 'Please enter amount per product']
    },
    total_amount: {
        type: Number,
        required: [true, 'Please enter total amount customer needs to pay']
    },
    shipping_address: {
        type: String,
        required: [true, 'Shipping address is required']
    },
    shipping_city: {
        type: String,
        required: [true, 'Shipping address city is required']
    },
    shipping_postal_code: {
        type: Number,
        required: [true, 'Shipping address postal code is required']
    },
    shipping_mobile_no: {
        type: Number,
        required: [true, 'Shipping address mobile number is required']
    },
    status: {
        type: String,
        default: 'pending',
        enum: ['pending', 'confirmed', 'dispatched', 'delivered']
    },
    shipping_date: {
        type : Date,
        default: null
    },
    isDeleted: {
        type : Date,
        default: null
    },
    created_time: {
        type : Date,
        default: Date.now
    },
    updated_time: {
        type : Date,
        default: Date.now
    }
});

orderSchema.pre(/^find/, function(next){
    this.populate({
        path: 'user_id',
        select: 'name email mobile_no photo address_id',
    }).populate({
        path: 'product_id',
        select: '-__v -created_time -updated_time'
    });
    next();
});

module.exports = mongoose.model("Order", orderSchema);