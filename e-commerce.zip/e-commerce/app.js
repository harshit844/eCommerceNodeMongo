const express = require("express");
const cors = require("cors");
const app = express();
const cookieParser = require('cookie-parser');
const errorMiddleware = require("./middleware/error");
const rateLimit = require('express-rate-limit');
const dotenv = require('dotenv');
const bodyParser = require('body-parser');
const helmet = require('helmet');
const mongoSanitize = require('express-mongo-sanitize');
const xss = require('xss-clean');
const hpp = require('hpp');
const cookies = require("cookie-parser");
/* const compression = require("compression"); */

// route imports
const user = require('./routes/userRoutes');
const dashboard = require('./routes/dashboardRoutes');
const order = require('./routes/orderRoutes');
const category = require('./routes/categoryRoutes');
const address = require('./routes/addressRoutes');
const banner = require('./routes/bannerRoutes');
const product = require('./routes/productRoutes');
const review = require('./routes/reviewRoutes');
const cart = require('./routes/cartRoutes');
const wishlist = require('./routes/wishlistRoutes');

// for webhook purpose
const orderController = require('./controllers/orderController');

// rate limit to all API
const apiLimiter = rateLimit({
	windowMs: process.env.API_RATE_LIMITER_STIME * 1000, // API_RATE_LIMITER_STIME seconds
	max: process.env.API_RATE_LIMITER_REQ_COUNT, // Limit each IP to API_RATE_LIMITER_REQ_COUNT requests per `window`
	message: {
		success: true,
		message: 'Too many request from this IP, please try again after some time'
	},
	standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
	legacyHeaders: false, // Disable the `X-RateLimit-*` headers
});

// config
dotenv.config({path:"config/config.env"});

// set security headers
app.use(helmet());

// Data sanitization againest nosql query injection
app.use(mongoSanitize());

// Data sanitization againest (XSS) malicious cross site scripts
app.use(xss());

// prevent parameter pollution
// if wanted to use same multiple parameters then add whitelisted array inside hpp
app.use(hpp());

// we need this not in json but in row form that's why it's not in route file (stripe webhook)
app.post(
	'/webhook-checkout'
	, bodyParser.raw({type: 'application/json'})
	, orderController.webhookCheckout
);

// body parser, reading data from the body into req.body
app.use(express.json({ limit: '10kb' }))
app.use(express.static(`${__dirname}/public`))
app.use(cookieParser());
app.use(bodyParser.urlencoded({
	extended: false
}));

// cors issue with node and react js
const corsOptions = {
	origin: ['http://localhost:4000'],
	credentials: true
};

// app.use(cors());
app.use(cors(corsOptions));
// this one is for the put patch kind of methods
app.options('*', cors());
app.use(cookies());

// rate limiter to all API
app.use("/api", apiLimiter);

// use route
app.use("/api/v1/customer/address/", address);
app.use("/api/v1/customer/", user);
app.use("/api/v1/dashboard/", dashboard);
app.use("/api/v1/order/", order);
app.use("/api/v1/category/", category);
app.use("/api/v1/banner/", banner);
app.use("/api/v1/product/", product);
app.use("/api/v1/product/review/", review);
app.use("/api/v1/cart/", cart);
app.use("/api/v1/wishlist/", wishlist);

// 404 handler
app.all('*', (req, res, next) => {
	const err = new Error(`Can't find this (${req.originalUrl}) URL`);
	err.statusCode = 404;
	err.message = `Can't find this (${req.originalUrl}) URL`;
	next(err);
})

// middleware for error
app.use(errorMiddleware);

module.exports = app;