const Wishlist = require('../modals/wishlistModel');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/wishlistModel');
const factory = require('../utils/handlerFactory');

exports.deleteWishlist = factory.deleteOne(Wishlist);

exports.createWishlist = catchAsyncErrors(async (req, res, next) => {
    let wishlist = await Wishlist.findOne({
        user_id: req.user._id,
        product_id: req.body.product_id
    });
    
    if(wishlist){
        const del = await Wishlist.findByIdAndDelete(wishlist.id);
        /* const del = await Wishlist.deleteOne({
            user_id: req.user._id,
            product_id: req.body.product_id
        }); */
        if (!del) {
            errorHandler(`No document with that Id`, 404, '', res);
        }
        
        res.status(204).send({
            success: true,
            message: "Document deleted successfully",
            data: {}
        });
    }else{
        const doc = await Wishlist.create({
            user_id: req.user._id,
            product_id: req.body.product_id
        });
    
        if(!doc){
            errorHandler(`Something went wrong, please try again later`, 400, '', res);
        }
    
        res.status(201).send({
            success: true,
            message: `Document created successfully`,
            data: {
                'data': doc
            }
        });
    }
});

exports.getAllUserWishlist = catchAsyncErrors(async (req, res, next) => {
    const doc = await Wishlist.find({
        user_id: req.user._id
    }).sort({ "created_time": -1 });

    if (!doc) {
        errorHandler(`No document found`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            'doc': doc
        }
    });
});