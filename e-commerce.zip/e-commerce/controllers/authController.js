const User = require('../modals/userModel');
const OTP = require('../modals/otpModel');
const { generateRandomOtp } = require('../utils/helper');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const jwt = require('jsonwebtoken');
const Email = require('../utils/sendEmail');
const crypto = require('crypto');
const sendToken = require('../utils/jwtToken');
const errorHandler = require('../utils/errorHandler');
const multer = require('multer');
const {
    findOne
} = require('../modals/userModel');

// multer start
const multerStorage = multer.memoryStorage();
const multerFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image')) {
        cb(null, true)
    } else {
        cb(errorHandler("Not an image! Please upload only images", 400, '', res), false)
    }
}

const upload = multer({
    storage: multerStorage,
    fileFilter: multerFilter,
    limits: {
        fileSize: 2 * 1024 * 1024, // No larger than 2mb
        fieldSize: 2 * 1024 * 1024, // No larger than 2mb
    }
});
// multer end

// generate OTP
exports.generateOtp = catchAsyncErrors(async (req, res, next) => {
    const generatedOtp = generateRandomOtp();
    let mobileNo, newOtpRow;
    const currentDate = new Date();

    const user = await User.findOne({
        mobile_no: req.body.mobile_no
    });
    if (!user) {
        errorHandler("Invalid User", 401, '', res);
    }
    mobileNo = user.mobile_no;

    // OTP Rate Limit
    let otpRow = await OTP.findOne({
        mobile_no: mobileNo
    });
    if (otpRow) {
        const updateQuery = {
            mobile_no: mobileNo
        };
        const otpUpdateTime = otpRow.updated_time;

        if (otpRow.retry_count >= process.env.OTP_RATE_LIMITER_COUNT) {
            const otpLastUpdatedTime = otpUpdateTime.getTime() + process.env.OTP_RATE_LIMITER_MTIME * 60000;

            if (currentDate.getTime() > otpLastUpdatedTime) {
                const newValues = {
                    $set: {
                        retry_count: 1,
                        otp_sent: generatedOtp,
                        updated_time: currentDate,
                        expiration: new Date(currentDate.getTime() + process.env.OTP_EXPIRY_TIME * 60000)
                    }
                };
                newOtpRow = await OTP.updateOne(updateQuery, newValues);
            } else {
                const errMsg = `OTP rate limit has been exceeded, Please try again after ${process.env.OTP_RATE_LIMITER_MTIME} minutes`;
                
                res.status(401).send({
                    success: true,
                    message: errMsg,
                    data: {}
                });
            }
        } else {
            const newRetryCountValue = otpRow.retry_count + 1;
            const newValues = {
                $set: {
                    retry_count: newRetryCountValue,
                    otp_sent: generatedOtp,
                    updated_time: currentDate,
                    expiration: new Date(currentDate.getTime() + process.env.OTP_EXPIRY_TIME * 60000)
                }
            };
            newOtpRow = await OTP.updateOne(updateQuery, newValues);
        }
    } else {
        newOtpRow = await OTP.create({
            mobile_no: mobileNo,
            otp_sent: generatedOtp,
            retry_count: 1,
            expiration: new Date(currentDate.getTime() + process.env.OTP_EXPIRY_TIME * 60000)
        });
    }

    res.status(200).send({
        success: true,
        message: "Otp sent successfully",
        data: {}
    });
})

// confirm OTP (Login)
exports.otpLogin = catchAsyncErrors(async (req, res, next) => {
    const validateOTPValue = await validateOTP(req.body.mobile_no, req.body.otp);
    
    if (validateOTPValue.success !== true) {
        res.status(401).send({
            success: true,
            message: 'Invalid OTP',
            data: {}
        });
    }
    
    const query = {
        mobile_no: req.body.mobile_no
    };
    const user = await User.findOne(query);
    
    sendToken(user, 200, "User logged in successfully", res);
})

// validate otp
async function validateOTP(mobileNo, inputOtp) {
    let otpRow = await OTP.findOne({
        mobile_no: mobileNo
    });
    
    if (otpRow) {
        const updateQuery = {
            mobile_no: mobileNo
        };
        const currentDate = new Date();
        const otpUpdateTime = otpRow.updated_time;

        if (otpRow.retry_count >= process.env.OTP_RATE_LIMITER_COUNT) {
            const otpLastUpdatedTime = otpUpdateTime.getTime() + process.env.OTP_RATE_LIMITER_MTIME * 60000;

            if (currentDate.getTime() > otpLastUpdatedTime) {
                const newValues = {
                    $set: {
                        retry_count: 1,
                        updated_time: currentDate,
                        expiration: new Date(currentDate.getTime() + process.env.OTP_EXPIRY_TIME * 60000)
                    }
                };
                await OTP.updateOne(updateQuery, newValues);
            } else {
                const errMsg = `OTP rate limit has been exceeded, Please try again after ${process.env.OTP_RATE_LIMITER_MTIME} minutes`;
                return {
                    success: false,
                    message: errMsg
                }
            }
        } else {
            const newRetryCountValue = otpRow.retry_count + 1;
            const newValues = {
                $set: {
                    retry_count: newRetryCountValue,
                    updated_time: currentDate,
                    expiration: new Date(currentDate.getTime() + process.env.OTP_EXPIRY_TIME * 60000)
                }
            };
            await OTP.updateOne(updateQuery, newValues);
        }
    }


    if (otpRow.otp_sent === inputOtp) {
        const expiryTime = otpRow.expiration;
        const currentDate = new Date();

        if (expiryTime.getTime() <= currentDate.getTime()) {
            return {
                success: false,
                message: 'OTP Expired!'
            };
        }
    } else {
        return {
            success: false,
            message: 'Wrong OTP!'
        };
    }
    
    return {
        success: true
    }
}

// Register a admin user
exports.registerUser = catchAsyncErrors(async (req, res, next) => {
    const {
        name,
        mobile_no,
        email,
        password,
        role
    } = req.body;

    const user = await User.create({
        name,
        mobile_no,
        email,
        password,
        role
    });

    if (!user) {
        errorHandler("Something went wrong", 401, '', res);
    } else {
        const url = `${req.protocol}://${req.get('host')}/login`;
        await new Email(user, url).sendWelcome();
        
        res.status(201).send({
            success: true,
            message: `User registered successfully`,
            data: {}
        });
    }
});

// login User
exports.loginUser = catchAsyncErrors(async (req, res, next) => {
    const {
        email,
        password
    } = req.body;

    if (!email || !password) {
        errorHandler("Please enter email & password", 400, '', res);
    }
    
    // +password is bcz is hidden from mongo view
    const user = await User.findOne({
        email: email
    }).select("+password");
    
    if (!user) {
        errorHandler("Invalid user, please connect with admin", 401, '', res);
    }

    const isPasswordMatched = await user.comparePassword(password);
    if (!isPasswordMatched) {
        errorHandler("Invalid email or password", 401, '', res);
    }

    sendToken(user, 200, "User logged in successfully", res);
});

// user logout
exports.userLogout = catchAsyncErrors(async (req, res, next) => {
    res.cookie("token", null, {
        expires: new Date(Date.now()),
        httpOnly: true
    });

    res.status(200).send({
        success: true,
        message: "Logged out successfully",
        data: {}
    });
});

// forgot password
exports.forgotPassword = catchAsyncErrors(async (req, res, next) => {
    const user = await User.findOne({
        email: req.body.email
    });
    if (!user) {
        errorHandler("User not found", 404, '', res);
    }

    // get user resetPasswordToken
    const resetToken = user.getResetPasswordToken();
    await user.save({
        validateBeforeSave: false
    });

    try {
        // this url is for front-end page
        const resetPasswordUrl = `${req.protocol}://${req.get('host')}/reset-password/${resetToken}`;
        console.log('resetPasswordUrl-',resetPasswordUrl);
        
        // message added in the pug template already
        /* const message = `Your password reset token is : ${resetPasswordUrl} \n\nIf you have not requested this request then, please ignore it` */
        /* await sendEmail({
            email: user.email,
            subject: `Meeting-Romm Password Recovery`,
            message
        }); */
        
        await new Email(user, resetPasswordUrl).sendPasswordReset();

        res.status(200).send({
            success: true,
            message: `Email sent to ${req.body.email} successfully`,
            data: {}
        });
    } catch (error) {
        user.resetPasswordToken = undefined;
        user.resetPasswordExpiry = undefined;

        await user.save({
            validateBeforeSave: false
        });
        errorHandler(error.message, 500, '', res);
    }
});

// reset password
exports.resetPassword = catchAsyncErrors(async (req, res, next) => {
    // creating hash of the token
    const resetPasswordToken = crypto.createHash("sha256").update(req.body.token).digest("hex");
    const user = await User.findOne({
        resetPasswordToken,
        resetPasswordExpiry: {
            $gt: new Date()
        }
    });

    if (!user) {
        errorHandler("Reset password token invalid or has been expired, '', res", 400);
    }

    if (req.body.password !== req.body.confirmPassword) {
        errorHandler("Password does not match", 400, '', res);
    }

    user.password = req.body.password;
    user.resetPasswordToken = undefined;
    user.resetPasswordExpiry = undefined;

    await user.save();
    res.status(200).send({
        success: true,
        message: `Password reset successfully`,
        data: {}
    });
});

// update user password
exports.updatePassword = catchAsyncErrors(async (req, res, next) => {
    const _id = req.user._id;
    const user = await User.findById(_id).select("+password");
    if (!user) {
        errorHandler(`No user with this id: ${_id}`, 404, '', res);
    }

    const isPasswordMatched = await user.comparePassword(req.body.oldPassword);
    if (!isPasswordMatched) {
        errorHandler("Old password is incorrect", 401, '', res);
    }

    if (req.body.newPassword != req.body.confirmPassword) {
        errorHandler("Password does not match", 401, '', res);
    }

    user.password = req.body.newPassword;
    await user.save();

    sendToken(user, 200, 'Password updated successfully', res);
});

// auth user
exports.tokenVerification = catchAsyncErrors(async (req, res, next) => {
    const token = req.body.token ? req.body.token : req.headers.cookies;
    if (!token) {
        errorHandler("Please login to access private modules", 401, '', res);
    }
    
    const decodedData = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decodedData._id);

    if (user) {
        res.status(200).send({
            success: true,
            message: "User authorized successfully",
            data: {
                'data': user
            }
        });
    } else {
        res.status(401).send({
            success: true,
            message: "Please login to access private modules",
            data: {}
        });
    }
});