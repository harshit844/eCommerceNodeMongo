const Review = require('../modals/reviewModel');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/reviewModel');
const factory = require('../utils/handlerFactory');

exports.createUserReview = catchAsyncErrors(async (req, res, next) => {
    req.body.user_id = req.user._id;
    next();
});

exports.createReview = factory.createOne(Review);
exports.updateReview = factory.updateOne(Review);
exports.getSingleReview = factory.findOne(Review);
exports.deleteReview = factory.softDeleteOne(Review);