const Order = require('../modals/orderModel');
const User = require('../modals/userModel');
const Product = require('../modals/productModel');
const stripe = require('stripe')('sk_test_51O2upPSDX0zZUJt7wJR17IIMjANun5yG4ZM8VQAAuJwHG6m0SLukTjWcnSKx1NxIoui2RZScGk2hs5MmMywJp4bz00dveySqsZ');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/orderModel');
const factory = require('../utils/handlerFactory');

exports.createOrderMiddleware = async (req, res, next) => {
    req.body.user_id = req.user.id;
    next();
}

exports.getAllUserOrders = catchAsyncErrors(async (req, res, next) => {
    const doc = await Order.find({
        user_id: req.user._id
    }).sort({ "created_time": -1 });

    if (!doc) {
        errorHandler(`No document found for that user`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            doc
        }
    });
});

exports.createOrder = factory.createOne(Order);
exports.updateOrder = factory.updateOne(Order);
exports.getAllOrders = factory.findAll(Order);
exports.getSingleOrder = factory.findOne(Order);
exports.deleteOrder = factory.softDeleteOne(Order);

// request payment method
exports.getCheckoutSession = catchAsyncErrors(async (req, res, next) => {
    // 1 get ordered product
    const order = await Order.findById(req.params.orderID);
    
    // 2 create checkout session
    const product = await stripe.products.create({
        name: `${order.product_id.name} - product`,
        description: `${order.product_id.description} - description`,
        images: ['https://img1.exportersindia.com/product_images/bc-full/dir_17/491370/luxury-wool-antique-rugs-carpets-home-1523536728-3777324.jpeg']
    });
      
    const price = await stripe.prices.create({
        product: product.id,
        currency: 'inr',
        unit_amount: order.total_amount * 100
    });

    const session = await stripe.checkout.sessions.create({
        line_items: [{
            price: price.id,
            quantity: 1,
        }],
        mode: 'payment',
        success_url: `${req.protocol}://${process.env.DOMAIN}/`,
        cancel_url: `${req.protocol}://${process.env.DOMAIN}/`,
        payment_method_types: ['card'],
        client_reference_id: req.params.orderID,
        customer_email: req.user.email
    });

    // create session as response
    res.status(200).send({
        success: true,
        message: "Ordered successfully",
        data: {
            sessionId: session.id
        }
    });
});

// not completed because not on server
const updateOrderCheckout = async session => {
    const orderID = session.client_reference_id;
    const user = (await User.findOne({
        email: session.customer_email
    })).id;
    const price = session.amount_total;
    const newData = {
        status: session.status
    }

    await Order.findByIdAndUpdate({_id: orderID}, newData, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });
}

// payment webhook
exports.webhookCheckout = catchAsyncErrors(async (req, res, next) => {
    const signature = req.headers['stripe-signature'];
    let event;

    try{
        event = stripe.webhooks.constructEvent(req.body, signature, process.env.STRIPE_WEBHOOK_SECRET);
    }
    catch(e){
        res.status(400).send({
            success: true,
            message: `Webhook error ${e.message}`,
            data: {
                sessionId: session.id
            }
        });
    }

    if(event.type === 'checkout.session.completed')
        updateOrderCheckout(event.data.object);
});