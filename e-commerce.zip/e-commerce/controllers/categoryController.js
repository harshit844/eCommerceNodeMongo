const Category = require('../modals/categoryModel');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/categoryModel');
const factory = require('../utils/handlerFactory');
const multer = require('multer');
const sharp = require('sharp');

// multer start
const multerStorage = multer.memoryStorage();
const multerFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image')) {
        cb(null, true)
    } else {
        cb(errorHandler("Not an image! Please upload only images", 400, '', res), false)
    }
}

const upload = multer({
    storage: multerStorage,
    fileFilter: multerFilter,
    limits: {
        fileSize: 2 * 1024 * 1024, // No larger than 2mb
        fieldSize: 2 * 1024 * 1024, // No larger than 2mb
    }
});

exports.updateCategoryPhotoMiddleware = catchAsyncErrors(async (req, res, next) => {
    const doc = await Category.findById(req.params.id);
    req.body.photo = req.file ? req.file.filename : (doc ? doc.photo : null)
    next();
});

exports.uploadCategoryImg = upload.single('photo');
exports.resizeCategoryImg = (req, res, next) => {
    if (!req.file) return next();
    
    req.file.filename = `category-${req.user._id}-${Date.now()}.jpeg`;

    sharp(req.file.buffer)
        .resize(200, 200)
        .toFormat('jpeg')
        .jpeg({quality: 70})
        .toFile(`public/images/categories/${req.file.filename}`);
    
    next();
}
// multer end

exports.createCategory = factory.createOne(Category);
exports.updateCategory = factory.updateOne(Category);
exports.getAllCategories = factory.findAll(Category);
exports.getSingleCategory = factory.findOne(Category);
exports.deleteCategory = factory.softDeleteOne(Category);