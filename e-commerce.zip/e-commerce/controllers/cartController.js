const Cart = require('../modals/cartModel');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/cartModel');
const factory = require('../utils/handlerFactory');

exports.deleteCart = factory.deleteOne(Cart);

exports.updateCart = catchAsyncErrors(async (req, res, next) => {
    if(req.body.quantity === 0){
        const del = await Cart.deleteOne({
            user_id: req.user._id,
            product_id: req.body.product_id
        });

        if (!del) {
            errorHandler(`No document with that Id`, 404, '', res);
        }
        
        res.status(204).send({
            success: true,
            message: "Document deleted successfully",
            data: {}
        });
    }
    
    const doc = await Cart.findOneAndUpdate({
        user_id: req.user._id,
        product_id: req.body.product_id
    }, req.body, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });
    
    if(!doc){
        errorHandler(`Item not found`, 400, '', res);
    }

    res.status(200).send({
        success: true,
        message: `Document updated successfully`,
        data: {
            'data': doc
        }
    });
});

exports.createCart = catchAsyncErrors(async (req, res, next) => {
    let cart = await Cart.findOne({
        user_id: req.user._id,
        product_id: req.body.product_id
    });
    let doc = '';

    if(cart){
        let quantitySum = cart.quantity + 1;
        doc = await Cart.findByIdAndUpdate({_id: cart.id}, {
            quantity: quantitySum
        }, {
            new: true,
            runValidators: true,
            useFindAndModify: false
        });
    }else{
        doc = await Cart.create(req.body);
    }

    if(!doc){
        errorHandler(`Something went wrong, please try again later`, 400, '', res);
    }

    res.status(201).send({
        success: true,
        message: `Document created successfully`,
        data: {
            'data': doc
        }
    });
});

exports.getAllUserCart = catchAsyncErrors(async (req, res, next) => {
    const doc = await Cart.find({
        user_id: req.user._id
    }).sort({ "created_time": -1 });

    if (!doc) {
        errorHandler(`No document found`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            'doc': doc
        }
    });
});