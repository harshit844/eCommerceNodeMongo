const User = require('../modals/userModel');
const Category = require('../modals/categoryModel');
const Order = require('../modals/orderModel');
const Product = require('../modals/productModel');

const catchAsyncErrors = require('../middleware/catchAsyncError');
const sendToken = require('../utils/jwtToken');

exports.getDashboard = catchAsyncErrors(async (req, res, next) => {
    const customers = await User.count();
    const categories = await Category.count();
    const orders = await Order.count();
    const products = await Product.count();
    
    res.status(200).send({
        success: true,
        message: "Dasboard info fetched successfully",
        data: {
            'customers': customers,
            'categories': categories,
            'orders': orders,
            'products': products
        }
    });
})