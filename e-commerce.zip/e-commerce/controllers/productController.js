const Product = require('../modals/productModel');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/productModel');
const factory = require('../utils/handlerFactory');
const multer = require('multer');
const sharp = require('sharp');

// multer start
const multerStorage = multer.memoryStorage();
const multerFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image')) {
        cb(null, true)
    } else {
        cb(errorHandler("Not an image! Please upload only images", 400, '', res), false)
    }
}

const upload = multer({
    storage: multerStorage,
    fileFilter: multerFilter,
    limits: {
        fileSize: 2 * 1024 * 1024, // No larger than 2mb
        fieldSize: 2 * 1024 * 1024, // No larger than 2mb
    }
});

exports.updateProductPhotoMiddleware = catchAsyncErrors(async (req, res, next) => {
    const doc = await Product.findById(req.params.id);
    req.body.photo = req.file ? req.file.filename : (doc ? doc.photo : null)
    next();
});

exports.uploadProductImg = upload.single('photo');
exports.resizeProductImg = (req, res, next) => {
    if (!req.file) return next();
    
    req.file.filename = `product-${req.user._id}-${Date.now()}.jpeg`;

    sharp(req.file.buffer)
        /* .fit('contain') */
        .toFormat('jpeg')
        .jpeg({quality: 100})
        .toFile(`public/images/products/${req.file.filename}`);
    
    next();
}
// multer end

exports.getAllProduct = factory.findAll(Product);
exports.createProduct = factory.createOne(Product);
exports.updateProduct = factory.updateOne(Product);
exports.deleteProduct = factory.softDeleteOne(Product);

exports.getSingleProduct = catchAsyncErrors(async (req, res, next) => {
    const doc = await Product.findById(req.params.id).populate('reviews');
    
    if (!doc) {
        errorHandler(`No document found with that ID`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            doc
        }
    });
});