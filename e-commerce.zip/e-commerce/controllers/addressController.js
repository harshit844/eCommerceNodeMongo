const Address = require('../modals/addressModel');
const errorHandler = require('../utils/errorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const {
    findOne
} = require('../modals/addressModel');
const factory = require('../utils/handlerFactory');

exports.createUserAddress = catchAsyncErrors(async (req, res, next) => {
    req.body.user_id = req.user._id;
    next();
});

exports.createAddress = factory.createOne(Address);
exports.updateAddress = factory.updateOne(Address);
exports.getSingleAddress = factory.findOne(Address);
exports.deleteAddress = factory.softDeleteOne(Address);

exports.getAllUserAddress = catchAsyncErrors(async (req, res, next) => {
    const doc = await Address.find({ 
        user_id: req.user._id 
    }).sort({ "created_time": -1 });
    if (!doc) {
        errorHandler(`No document found`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            'doc': doc
        }
    });
});
