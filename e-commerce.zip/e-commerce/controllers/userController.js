const User = require('../modals/userModel');
const OTP = require('../modals/otpModel');
const catchAsyncErrors = require('../middleware/catchAsyncError');
const { generateRandomOtp } = require('../utils/helper');
const factory = require('../utils/handlerFactory');
const errorHandler = require('../utils/errorHandler');
const multer = require('multer');
const sharp = require('sharp');
const {
    findOne
} = require('../modals/userModel');

// multer functions for upload image

// commented because we are no longer saving files in the storage but instead in the memory and using resizeImg method
/* const multerStorage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/images/users');
    },
    filename: (req, file, cb) => {
        const ext = file.mimetype.split('/')[1];
        cb(null, `user-${req.user._id}-${Date.now()}.${ext}`)
    }
}); */

// multer start
const multerStorage = multer.memoryStorage();
const multerFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('image')) {
        cb(null, true)
    } else {
        cb(errorHandler("Not an image! Please upload only images", 400, '', res), false)
    }
}

const upload = multer({
    storage: multerStorage,
    fileFilter: multerFilter,
    limits: {
        fileSize: 2 * 1024 * 1024, // No larger than 2mb
        fieldSize: 2 * 1024 * 1024, // No larger than 2mb
    }
});
// multer end

exports.uploadUserImg = upload.single('photo');
exports.resizeUserImg = (req, res, next) => {
    if (!req.file) return next();
    
    req.file.filename = `user-${req.user._id}-${Date.now()}.jpeg`;

    sharp(req.file.buffer)
        .resize(200, 200)
        .toFormat('jpeg')
        .jpeg({quality: 60})
        .toFile(`public/images/users/${req.file.filename}`);
    
    next();
}

// update user
exports.updateUserPhotoMiddleware = catchAsyncErrors(async (req, res, next) => {
    const doc = await User.findById(req.user._id);
    req.body.photo = req.file ? req.file.filename : (doc ? doc.photo : null)
    next();
});

exports.updateProfile = factory.updateOneFromBodyID(User);
exports.updateProfileById = factory.updateOne(User);

// get all users (admin)
exports.getAllUsers = factory.findAll(User);

// get single user
exports.getSingleUser = factory.findOne(User);

// delete user
exports.deleteUser = factory.softDeleteOne(User);