const mongoose = require('mongoose');

const DB = () => {
    mongoose
        .connect(process.env.DB_URI, {
            useNewUrlParser:true, 
            useUnifiedTopology:true
        })
        .then((data) => {
            console.log(`mongoDB connected with server: ${data.connection.host}`);
        });
    // Removed this catch bcz added unhandled promise rejection will take care of this
    // .catch((error) => {
    //     console.log(`mongo error: ${error}`);
    // });
}

module.exports = DB;