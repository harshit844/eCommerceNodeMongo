const express = require('express');
const {
    getDashboard
} = require('../controllers/dashboardController');

const {
    isAuthenticateUser,
    authorizeRole
} = require('../middleware/auth');

const router = express.Router();

router.use(isAuthenticateUser);
router.use(authorizeRole('admin'));

router.route("/").get(getDashboard);

module.exports = router;