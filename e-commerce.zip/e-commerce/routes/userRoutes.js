const express = require('express');
const {
    registerUser,
    loginUser,
    userLogout,
    forgotPassword,
    resetPassword,
    updatePassword,
    generateOtp,
    otpLogin,
    tokenVerification
} = require('../controllers/authController');

const {
    getUserProfile,
    updateProfile,
    getAllUsers,
    getSingleUser,
    deleteUser,
    resizeImg,
    updateProfileById,
    updateUserPhotoMiddleware,
    resizeUserImg,
    uploadUserImg
} = require('../controllers/userController');

const {
    isAuthenticateUser,
    authorizeRole
} = require('../middleware/auth');

const router = express.Router();

router.route("/signup").post(registerUser);
router.route("/admin/login").post(loginUser);

router.route("/password/forgot").post(forgotPassword);
router.route("/password/reset").patch(resetPassword);
router.route("/generateOtp").post(generateOtp);
router.route("/login").post(otpLogin);

router.use(isAuthenticateUser);

// authenticate API
router.route("/tokenVerification").post(tokenVerification);

router.route("/password/update").post(updatePassword);
router.route("/logout").get(userLogout);
router.route("/update").post(uploadUserImg
    ,resizeUserImg
    ,updateUserPhotoMiddleware
    ,updateProfile
);

// admin role middleware
router.use(authorizeRole('admin'));

router.route("/").get(getAllUsers);
router.route("/:id")
    .get(getSingleUser)
    .patch(updateProfileById)
    .delete(deleteUser);

module.exports = router;