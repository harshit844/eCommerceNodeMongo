const express = require('express');
const {
    createCategory,
    getAllCategories,
    updateCategory,
    getSingleCategory,
    deleteCategory,
    uploadCategoryImg,
    resizeCategoryImg,
    updateCategoryPhotoMiddleware
} = require('../controllers/categoryController');

const {
    isAuthenticateUser,
    authorizeRole
} = require('../middleware/auth');

const router = express.Router();

router.route("/").get(getAllCategories);

router.use(isAuthenticateUser);

router.route("/:id").get(getSingleCategory)

router.use(authorizeRole('admin'));

router.route("/:id")
    .delete(deleteCategory)
    .patch(
        uploadCategoryImg
        ,resizeCategoryImg
        ,updateCategoryPhotoMiddleware
        ,updateCategory
    );

router.route("/create").post(
    uploadCategoryImg
    ,resizeCategoryImg
    ,updateCategoryPhotoMiddleware
    ,createCategory
);

module.exports = router;