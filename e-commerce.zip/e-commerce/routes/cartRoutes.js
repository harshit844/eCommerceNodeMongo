const express = require('express');
const {
    createCart,
    getAllUserCart,
    updateCart,
    deleteCart
} = require('../controllers/cartController');

const { isAuthenticateUser } = require('../middleware/auth');

const router = express.Router();

router.use(isAuthenticateUser);

router.route("/").get(getAllUserCart);
router.route("/create").post(createCart);
router.route("/:id").delete(deleteCart).patch(updateCart);

module.exports = router;