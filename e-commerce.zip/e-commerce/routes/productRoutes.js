const express = require('express');
const {
    createProduct,
    getAllProduct,
    updateProduct,
    getSingleProduct,
    deleteProduct,
    uploadProductImg,
    resizeProductImg,
    updateProductPhotoMiddleware,
    restoreDeletedProduct
} = require('../controllers/productController');

const { isAuthenticateUser, authorizeRole } = require('../middleware/auth');

const router = express.Router();

router.route("/").get(getAllProduct);
router.route("/:id").get(getSingleProduct)

router.use(isAuthenticateUser);
router.use(authorizeRole('admin'));

router.route("/create").post(
    uploadProductImg,
    resizeProductImg,
    updateProductPhotoMiddleware,
    createProduct
);
router.route("/:id").delete(deleteProduct).patch(
    uploadProductImg,
    resizeProductImg,
    updateProductPhotoMiddleware,
    updateProduct
);

module.exports = router;