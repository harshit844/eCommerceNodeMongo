const express = require('express');
const {
    createBanner,
    getAllBanner,
    updateBanner,
    getSingleBanner,
    deleteBanner,
    uploadBannerImg,
    resizeBannerImg,
    updateBannerPhotoMiddleware
} = require('../controllers/bannerController');

const { isAuthenticateUser, authorizeRole } = require('../middleware/auth');

const router = express.Router();

router.route("/").get(getAllBanner);

router.use(isAuthenticateUser);
router.use(authorizeRole('admin'));

router.route("/create").post(
    uploadBannerImg,
    resizeBannerImg,
    updateBannerPhotoMiddleware,
    createBanner
);
router.route("/:id").get(getSingleBanner).delete(deleteBanner).patch(
    uploadBannerImg,
    resizeBannerImg,
    updateBannerPhotoMiddleware,
    updateBanner
);

module.exports = router;