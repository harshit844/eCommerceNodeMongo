const express = require('express');
const {
    createAddress,
    getAllUserAddress,
    updateAddress,
    getSingleAddress,
    deleteAddress,
    createUserAddress
} = require('../controllers/addressController');

const { isAuthenticateUser, authorizeRole } = require('../middleware/auth');

const router = express.Router();

router.use(isAuthenticateUser);
router.use(authorizeRole('user'));

router.route("/").get(getAllUserAddress);
router.route("/create").post(createUserAddress, createAddress);
router.route("/:id").get(getSingleAddress).delete(deleteAddress).patch(updateAddress);

module.exports = router;