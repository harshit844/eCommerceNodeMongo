const express = require('express');
const {
    createReview,
    getAllProductReview,
    updateReview,
    getSingleReview,
    deleteReview,
    createUserReview
} = require('../controllers/reviewController');

const { isAuthenticateUser } = require('../middleware/auth');

const router = express.Router();

router.use(isAuthenticateUser);

router.route("/create").post(createUserReview, createReview);
router.route("/:id").get(getSingleReview).delete(deleteReview).patch(updateReview);

module.exports = router;