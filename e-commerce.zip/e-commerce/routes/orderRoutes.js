const express = require('express');
const {
    createOrder,
    getAllOrders,
    updateOrder,
    getSingleOrder,
    deleteOrder,
    getAllUserOrders,
    getCheckoutSession,
    createOrderMiddleware
} = require('../controllers/orderController');

const {
    isAuthenticateUser,
    authorizeRole
} = require('../middleware/auth');

const router = express.Router();

router.route("/").get(getAllOrders);

router.use(isAuthenticateUser);

router.route("/create").post(createOrderMiddleware, createOrder);
router.route("/user").get(getAllUserOrders);
router.route("/checkout-session/:orderID").get(getCheckoutSession);
router.route("/:id").get(getSingleOrder);

router.use(authorizeRole('admin'));

router.route("/:id").patch(updateOrder).delete(deleteOrder);

module.exports = router;