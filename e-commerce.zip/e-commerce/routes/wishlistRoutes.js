const express = require('express');
const {
    createWishlist,
    getAllUserWishlist,
    deleteWishlist
} = require('../controllers/wishlistController');

const { isAuthenticateUser } = require('../middleware/auth');

const router = express.Router();

router.use(isAuthenticateUser);

router.route("/").get(getAllUserWishlist);
router.route("/create").post(createWishlist);
router.route("/:id").delete(deleteWishlist);

module.exports = router;