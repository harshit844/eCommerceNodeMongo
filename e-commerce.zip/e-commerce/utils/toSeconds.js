const toSeconds = async (time) => {
    const splitTime = time.split(':');
    const hoursToSec = splitTime[0] * 3600;
    const mintsToSec = splitTime[1] * 60;
    
    return hoursToSec + mintsToSec;
};

module.exports = toSeconds;