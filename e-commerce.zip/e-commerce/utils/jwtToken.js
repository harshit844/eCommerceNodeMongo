// create and storing token in cookie
const sendToken = (user,statusCode,msg,res) => {
    const token = user.getJWTToken();

    // option for coookie
    const options = {
        expires:new Date(
            Date.now() + process.env.COOKIE_EXPIRE *24*60*60*1000
        ),
        httpOnly:true
    }

    res.status(statusCode).cookie("token",token,options).send({
        success: true,
        message: msg,
        data: {
            'user': user,
            'token': token
        }
    });
}

module.exports = sendToken;