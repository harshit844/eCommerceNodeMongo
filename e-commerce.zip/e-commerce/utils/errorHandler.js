/* class ErrorHandler extends Error{
    constructor(message,statusCode,data,res){
        super(message);
        this.statusCode = statusCode;
        this.data = data;
        this.res = res;

        Error.captureStackTrace(this,this.constructor);
    }

    res.status(statusCode).send({
        success: true,
        message: message,
        data: {
            data
        }
    });
} */

const errorHandler = (message,statusCode,data,res) => {
    res.status(statusCode).send({
        success: true,
        message: message,
        data: {
            data
        }
    });
}

module.exports = errorHandler;