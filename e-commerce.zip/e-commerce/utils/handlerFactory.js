const catchAsyncErrors = require('../middleware/catchAsyncError');
const errorHandler = require('../utils/errorHandler');

exports.deleteOneFromBodyID = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.findByIdAndDelete(req.body.id);
    if (!doc) {
        errorHandler(`No document with that Id`, 404, '', res);
    }
    
    /* 204 status code for empty response which means successfull delete */
    res.status(200).send({
        success: true,
        message: "Document deleted successfully",
        data: {}
    });
});

exports.deleteOne = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.findByIdAndDelete(req.params.id);
    if (!doc) {
        errorHandler(`No document with that Id`, 404, '', res);
    }
    
    res.status(204).send({
        success: true,
        message: "Document deleted successfully",
        data: {}
    });
});

exports.softDeleteOne = Model => catchAsyncErrors(async (req, res, next) => {
    const newData = {
        isDeleted: Date.now()
    }

    const doc = await Model.findByIdAndUpdate({_id: req.params.id}, newData, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });

    if (!doc) {
        errorHandler(`No document with that Id`, 404, '', res);
    }
    
    res.status(204).send({
        success: true,
        message: "Document deleted successfully",
        data: {}
    });
});

exports.restoreSoftDeletedOne = Model => catchAsyncErrors(async (req, res, next) => {
    const newData = {
        isDeleted: null
    }

    const doc = await Model.findByIdAndUpdate({_id: req.params.id}, newData, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });

    if (!doc) {
        errorHandler(`No document with that Id`, 404, '', res);
    }
    
    res.status(200).send({
        success: true,
        message: "Document restored successfully",
        data: {
            'data': doc
        }
    });
});

exports.createOne = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.create(req.body);
    if(!doc){
        errorHandler(`Something went wrong, please try again later`, 400, '', res);
    }

    res.status(201).send({
        success: true,
        message: `Document created successfully`,
        data: {
            'data': doc
        }
    });
});

exports.updateOne = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.findByIdAndUpdate({_id: req.params.id}, req.body, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });
    
    if(!doc){
        errorHandler(`Document not found with that ID`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Document updated successfully",
        data: {
            'data': doc
        }
    });
});

exports.updateOneFromBodyID = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.findByIdAndUpdate({_id: req.user._id}, req.body, {
        new: true,
        runValidators: true,
        useFindAndModify: false
    });
    
    if(!doc){
        errorHandler(`Document not found with that ID`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Document updated successfully",
        data: {
            'data': doc
        }
    });
});

exports.findAll = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.find().sort({ "created_time": -1 });
    if (!doc) {
        errorHandler(`No document found`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            'data': doc
        }
    });
});

exports.findOne = Model => catchAsyncErrors(async (req, res, next) => {
    const doc = await Model.findById(req.params.id);
    if (!doc) {
        errorHandler(`No document found with that ID`, 404, '', res);
    }

    res.status(200).send({
        success: true,
        message: "Documents found successfully",
        data: {
            'data': doc
        }
    });
});