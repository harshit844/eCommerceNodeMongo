module.exports = (err,req,res,next) => {
    err.statusCode = err.statusCode || 500;
    err.message = err.message || "Internal server error";
    
    // wrong mongoDB ID error
    if(err.name == 'CastError'){
        err.message = `Resource not found: ${err.path}`;
    } 
    
    // mongoose validation error
    if(err.name == 'ValidationError'){
        const errors = Object.values(err.errors).map(el => el.message);        
        err.message = `Invalid input: ${errors.join('. ')}`;
    } 
    
    // 404 handler
    if(err.statusCode == 404){
        err.message = err.message;
    } 

    // mongoose duplicate error
    if(err.statusCode === 11000) {
        err.message = `Duplicate ${Object.keys(err.keyValue)} Entered`;
    }

    // wrong jwt token
    if(err.name == 'JsonWebTokenError'){
        err.message = `Json web token is invalid, Try again`;
    }

    // expired jwt token
    if(err.name == 'TokenExpiredError'){
        err.message = `Json web token is expired, Try again`;
    }
    
    // Bad request
    if(err.name == 'ERR_BAD_REQUEST'){
        err.message = `Bad request, Try again`;
    }
    
    // Bad response
    if(err.name == 'ERR_BAD_RESPONSE'){
        err.message = `Bad response, Try again`;
    }

    res.status(err.statusCode).send({
        success: true,
        message: err.message,
        data: {}
        // error:err.stack // (detailed error with file and line number)
    });
}