const errorHandler = require("../utils/errorHandler");
const catchAsyncError = require("./catchAsyncError");
const jwt = require('jsonwebtoken');
const User = require('../modals/userModel');
const dotenv = require('dotenv');

dotenv.config({path:"config.env"});

exports.isAuthenticateUser = catchAsyncError(async(req,res,next) => {
    const token = req.headers.cookies ? req.headers.cookies : req.headers.token;
    if(!token){
        errorHandler("Please login to access private modules", 401, '', res);
    }
    
    const decodedData = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await User.findById(decodedData._id);
    next();
});

exports.authorizeRole = (...roles) => {
    return (req, res, next) => {
        if(!roles.includes(req.user.role)){
            errorHandler(`Role: ${req.user.role} is not allowed to access this resource`, 401, '', res);
        }
        next();
    };
};